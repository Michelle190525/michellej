
// Clase que representa un turno médico
public class Turno
{
    public Paciente Paciente; // Información del paciente
    public string Fecha;      // Fecha del turno
    public string Hora;       // Hora del turno
}
